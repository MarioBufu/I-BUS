
import serial
import threading
from bluetooth import *

#Start BUS Reader
class BusReader(object):
    def __init__(self):
        self.thread = None
        self.handle = serial.Serial(
                port = '/dev/ttyUSB0',
                baudrate = 9600,
                parity = serial.PARITY_EVEN,
                timeout = 1,
                stopbits = 1)
    def parse(data):
        packets = []
        bus_dump = bytearray(data)
        packet = bytearray()

        def is_packet_complete():
            if len(packet) < 3:
                return False
            length = packet[1]
            entire_length = length + 2 # message length + IDs
            if len(packet) == entire_length:
                return True
            return False # safety return
        for index, byte in enumerate(bus_dump):
            packet.append(byte)
            if is_packet_complete():
                packets.append(packet)
                packet = bytearray()
        return packets

    def consumeBus(self):
        while self.handle:
            data = self.handle.read(1024)
            if len(data) > 0:
                 self.parse(data)
    def start(self):
        self.thread = threading.Thread(target = self.consumeBus)
        self.thread.deamon = True
        self.thread.start()
###########End bus reader
class ExampleBluetoothServer(object): 
    def __init__(self): 
        self.client_sock = None
        self.client_info = None
        self.rfcomm_channel = None
        self.service_name = "ConnectedBMW"
        self.service_uuid = '94f39d29-7d6d-437d-973b-fba39e49d4ee'
        self.server_sock = None
        self.thread = None 
        self.data = None
        self.ReceiveData = None
    def getReadData(self):
        return self.data
    def getReceiveData(self):
        return self.ReceiveData

    def sendBTData(msg):
        if not self.client_sock:
            print("Client not connected debug bluetooth")
        else:
            self.client_sock.send(msg + "\0")

    def consume_bus(self):
         try:
             print('starting to listen for bluetooth data...')
             print(self.client_sock)
             while self.client_sock:
                 self.data = self.client_sock.recv(1024)
                 if len(self.data) > 0:
                     self.ReceiveData = 1
                     #sendBTData("good")
                     self.client_sock.send("good \n")
                     print("data received: [%s]", self.data)
                 else:
                    self.ReceiveData = 1
         except Exception:
             print('bluetooth connection was interrupted')
             self.client_sock.close()
             self.server_sock.close()
             self.threadx.stop()
    def listen(self):
        # start listening for data
        print("Consume")
        self.consume_bus()
    def start(self):
        #####BTTEst
        print("Listen")
        # prepare bluetooth server
        self.server_sock = BluetoothSocket(RFCOMM)
        self.server_sock.bind(("", PORT_ANY))
        self.server_sock.listen(1)
        self.rfcomm_channel = self.server_sock.getsockname()[1]
        # start listening for incoming connections
        advertise_service(self.server_sock, self.service_name,
                          service_id=self.service_uuid,
                          service_classes=[self.service_uuid, SERIAL_PORT_CLASS],
                          profiles=[SERIAL_PORT_PROFILE])
        print('waiting for connection on RFCOMM channel %d', self.rfcomm_channel)
        # accept received connection
        self.client_sock, self.client_info = self.server_sock.accept()
        print('accepted connection from %r', self.client_info)
        ###BTEnD
        print("Start")
        self.threadx = threading.Thread(target = self.consume_bus)
        self.threadx.daemon = False
        self.threadx.start()
        #self.consume_bus()
        print('client soc %r', self.client_sock)
       
if __name__ == '__main__':
#    BusReader().start()
     ExampleBluetoothServer().start()
     try:
         while True:
             pass
         #sadas
     except Exception:
         print("end")
